# Bootstrap 4 Offline Documentation
Bootstrap 4 is new so many developers are yet to fully understand its inner workings and grid system , so most of us end up going online each time we want to check out how to do something as little as adding or styling a button. So i came up with this project to create a totally offline documentation for bootstrap 4

Please dont forget to star this project it if you find it helpful

Just download the unzip and click on index.html. 
Viola! Happy Coding !!!

Thank you

![alt text](http://getbootstrap.com/assets/img/bootstrap-stack.png)


